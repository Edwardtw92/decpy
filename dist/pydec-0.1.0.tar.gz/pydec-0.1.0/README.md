# DECpy: Discrete Exterior Calculus in Python
The project will be package and upload shortly with basic install guide.

Research at Perimeter Institute is supported in part by the Government of Canada through the Department of Innovation, Science and Economic Development and by the Province of Ontario through the Ministry of Colleges and Universities.
